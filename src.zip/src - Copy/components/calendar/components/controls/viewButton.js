import React from 'react';

import {testIds} from '../../data/tests';
import {getClasses} from '../../utils/classes'

const ViewButton = (props) => {
	const { title, view, targetView, classPrefix, onClick} = props;
	const testId = React.useMemo(
		() => (view === 'month' ? testIds.controlsMonthTitle : testIds.controlsYearTitle),
		[view]
	);
	const CViewButton = React.useMemo(
		() => getClasses([`calendar__controls-${view}`], classPrefix),
		[view, classPrefix]
	);
	
	const handlerClick = React.useCallback(
		() => onClick(targetView), [targetView, onClick]
	);
	
	return (
		<span
			className={CViewButton}
			data-testid={testId}
			onClick={handlerClick}
		>
			{ title }
		</span>
	);
};

export default React.memo(ViewButton);
