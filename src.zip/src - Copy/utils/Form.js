import {isObservable, isObservableArray, isObservableMap, isObservableObject, toJS} from "mobx";

class Form {

    fields = {};
    data = {};
    oneEvents = {};
    manyEvents = {};
    anyEvents;

    constructor(props) {
        this.onChange = this.onChange.bind(this);
        this.addChangeOne = this.addChangeOne.bind(this);
        this.addChangeMany = this.addChangeMany.bind(this);
        this.addChangeAny = this.addChangeAny.bind(this);
        this.getFormData = this.getFormData.bind(this);
    }

    onChange(val, name, el) {
        const eventOne = this.oneEvents[name];
        const eventMany = this.manyEvents[name];
        const {anyEvents} = this;
        if (Form.hasVal(val)) {
            if (el.props.type === 'number') {
                val = parseInt(val);
            }
            this.data[name] = val;
            this.fields[name] = el;
            eventOne && eventOne(el, val);
            eventMany && eventMany(el, name, val);
            anyEvents && anyEvents(el, name, val);
        } else if (isNullable(val) || (val.isEmpty && val.isEmpty())) {
            delete this.data[name];
            delete this.fields[name];
            eventOne && eventOne(el);
            eventMany && eventMany(el, name);
            anyEvents && anyEvents(el, name);
        }
    }

    addChangeOne(name, event) {
        this.oneEvents[name] = event;
    }

    addChangeMany(names, event) {
        if (isArray(names)) {
            names.forEach(name => {
                this.manyEvents[name] = event;
            });
        }
    }

    addChangeAny(event) {
        this.anyEvents = event;
    }

    isValid(name) {
        if (!isString(name)) {
            throw new Error(name + ' must be a string');
        }
        if (name in this.data) {
            const val = this.data[name];
            return Form.hasVal(val);
        }
        return false;
    }

    areValid(names) {
        if (isArray(names)) {
            for (var n = 0; n < names.length; n++) {
                if (!this.isValid(names[n]))
                    return false;
            }
            return true;
        } else if (isString(names)) {
            return this.isValid(names);
        } else {
            throw new Error(names + ' must be an array of a string');
        }
    }

    get(name) {
        if (!isString(name)) {
            throw new Error(name + ' must be a string');
        }

        return this.data[name];
    }

    getFormData(val, onlyValues) {
        let filterData = {};

        const convert = (arg) => {
            if (isObservable(arg)) {
                return toJS(arg);
            } else if (isObservableArray(arg)) {
                return convert(toJS(arg));
            } else if (isObservableObject(arg)) {
                return convert(toJS(arg));
            } else if (isObservableMap(arg)) {
                return convert(toJS(arg));
            } else if (isArray(arg)) {
                return arg.map(convert);
            }
            return arg;
        };

        const processObject = (val, key) => {
            if (isDate(val.start) || isDate(val.end)) {
                if (isDate(val.start)) {
                    filterData[key] = {start: val.start.getTime()};
                }
                if (isDate(val.end)) {
                    if (!filterData[key]) {
                        filterData[key] = {};
                    }
                    filterData[key].end = val.end.getTime();
                }
            } else if (val.path) {
                filterData[key] = val.path;
            } else if (val.id) {
                const {id, data} = val;
                if(id) {
                    filterData[key + '_id'] = id;
                }
                if(data) {
                    const {fname, lname, name, email, username} = data;
                    filterData[key] = {};
                    if(id) {
                        filterData[key]['id'] = id;
                    }
                    if(fname) {
                        filterData[key]['fname'] = fname;
                    }
                    if(lname) {
                        filterData[key]['lname'] = lname;
                    }
                    if(name) {
                        filterData[key]['name'] = name;
                    }
                    if(email) {
                        filterData[key]['email'] = email;
                    }
                    if(username) {
                        filterData[key]['username'] = username;
                    }
                } else {
                    const {fname, lname, name, email, username} = val;
                    filterData[key] = {};
                    if(id) {
                        filterData[key]['id'] = id;
                    }
                    if(fname) {
                        filterData[key]['fname'] = fname;
                    }
                    if(lname) {
                        filterData[key]['lname'] = lname;
                    }
                    if(name) {
                        filterData[key]['name'] = name;
                    }
                    if(email) {
                        filterData[key]['email'] = email;
                    }
                    if(username) {
                        filterData[key]['username'] = username;
                    }
                }
            } else {
                filterData[key] = val;
            }
        };

        val = (!isArray(val) && !isObservableArray(val)) ? [val] : val;
        val.forEach(key => {
            let val = !onlyValues ? this.get(key) : key;
            if (isDate(val)) {
                filterData[key] = val.getTime();
            } else if (isObservableArray(val) ||
                isArray(val)) {
                val = val.map(convert);
                if (!val.isEmpty()) {
                    filterData[key] = val;
                }
            } else if (isObservable(val) ||
                isObservableObject(val) ||
                isObservableMap(val)) {
                val = convert(val);
                if (!!val) {
                    processObject(val, key);
                }
            } else if (isObject(val)) {
                processObject(val, key);
            } else {
                filterData[key] = val;
            }
        });

        return filterData;
    }

    get formData() {
        if (this.hasData) {
            return this.getFormData(this.toKeys);
        }
    }

    get hasData() {
        return !Object.keys(this.data).isEmpty();
    }

    get toArray() {
        return Object.keys(this.data).map(key => this.data[key]);
    }

    get toKeys() {
        return Object.keys(this.data);
    }

    reset() {
        this.data = {};
        Object.values(this.fields).forEach(el => el.reset && el.reset());
        this.fields = {};
    }

    static hasVal(val) {
        return isNumber(val) || isBoolean(val) || (!isNullable(val) && (val.isEmpty && !val.isEmpty())) || !!val;
    }
}

export default Form;
